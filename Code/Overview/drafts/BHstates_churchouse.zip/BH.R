require('ggplot2')
require('dplyr')
require('tidyr')
require('lubridate')
require('rgdal')
require('maptools')
require('mapproj')
require('ggmap')
require(extrafont)
source('cctheme.R')
gpclibPermit()

BH<-read.csv("AMI_NSDUHStates2013.csv")
head (BH)

AMI<-read.csv("SAMHSAcleanAMIYr.csv")
head(AMI)

#map state numbers_bring in states long lat 
states<-readOGR(dsn='cb_2014_us_state_20m', layer = 'cb_2014_us_state_20m')
head(states)
#fortify takes polygon shape and forms the lat long - always have to fortify
states2<-fortify(states, region = 'NAME')
head(states2)
#join BH and states
BH2<-left_join(BH, states2, by=c('State'='id'))
head(BH2)

map<-ggplot(BH2, aes(x=long, y=lat, group=State, fill=X18orOlder))+
  geom_polygon(color="red", size=0.06)+
  coord_map()
print(map)

#chart this information by state
chart<-ggplot(BH2, aes(x=reorder(State, X18orOlder), y=X18orOlder))+
  geom_bar(stat="identity", width=0.15, color = "red")+
    coord_flip()+
    ylab("Thousands")+
    xlab("")+
  ggtitle("Any Mental Illness in Last 12 Months, Ages 18 and Older") 
  print(chart)
ggsave("chart.pdf", width = 8, height = 4)

